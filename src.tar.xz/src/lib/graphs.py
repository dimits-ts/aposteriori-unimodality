from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import numpy as np
import apunim

from . import preprocessing

# Okabe–Ito palette
COLORBLIND_PALETTE = [
    # --- Core ---
    "#000000",
    "#E69F00",
    "#56B4E9",
    "#009E73",
    "#F0E442",
    "#0072B2",
    "#D55E00",
    "#CC79A7",
    # --- Neutral / light extensions ---
    "#999999",
    "#8DD3C7",
    "#FDB462",
    "#B3DE69",
    "#80B1D3",
    "#FB8072",
    "#CAB2D6",
    "#BC80BD",
    # --- Additional medium/dark colors ---
    "#4D4D4D",
    "#1B9E77",
    "#7570B3",
    "#A6761D",
    "#66A61E",
    "#E7298A",
    "#A6CEE3",
    "#FFB000",
]

MARKERS = ["o", "s", "D", "^", "v", "P", "X"]
HATCHES = ["..", "\\\\", "++", "oo", "//", "xx", "**", "--"]

DEFAULT_FIGSIZE = (14, 6)


def polarization_plot(
    ds: preprocessing.Dataset, output_path: Path, dpi: int = 300
) -> None:
    df = ds.get_dataset()
    annotation_col = ds.get_annotation_column()
    sdb_columns = ds.get_sdb_columns()

    # Data Preparation
    all_annotations = []
    for annotations_list in df[annotation_col].to_list():
        if isinstance(annotations_list, (list, np.ndarray)):
            all_annotations.extend(annotations_list)

    if not all_annotations:
        print(
            "Warning: No valid annotations found. Cannot calculate polarization."
        )
        return

    bins = len(np.unique(all_annotations))

    records = []

    # ITERATE THROUGH ALL COMMENTS
    for _, row in df.iterrows():
        annotations = row[annotation_col]

        # Check if the comment has any annotations
        if (
            not isinstance(annotations, (list, np.ndarray))
            or len(annotations) == 0
        ):
            continue

        # Calculate NDFU for the entire comment (row)
        try:
            ndfu_value = apunim.dfu(annotations, bins=bins, normalized=True)
        except Exception as e:
            # Handle cases where the apunim function might fail
            print(f"Error calculating NDFU for an item: {e}")
            continue

        for sdb_col in sdb_columns:
            sdb_values = row[sdb_col]

            for value in sdb_values:
                combined_category = f"{sdb_col}: {value}"
                records.append(
                    {"PC Dimension": combined_category, "nDFU": ndfu_value}
                )

    plot_df = pd.DataFrame(records)

    # Note: Since the categories are now complex strings (e.g., "Race: Asian"),
    # setting a strict, predefined order is usually necessary for clean visualization.
    plot_df["PC Dimension"] = pd.Categorical(
        plot_df["PC Dimension"], ordered=True
    )

    fig, ax = plt.subplots()

    sns.boxplot(
        x="PC Dimension",
        y="nDFU",
        data=plot_df,
        ax=ax,
        # skip black color
        palette=COLORBLIND_PALETTE[1:],
    )

    ax.set_xlabel("Group")
    ax.set_ylabel("nDFU")
    ax.set_title(ds.get_name())

    ax.set_ylim(-0.05, 1.05)

    plt.xticks(rotation=90, ha="right")
    plt.grid(axis="y", alpha=0.5)

    save_plot(output_path, dpi)
    plt.close()


def save_plot(path: Path, dpi: int = 300) -> None:
    """
    Saves a plot to the specified filepath.

    :param path:
        The full path (including filename) where the plot will be saved.
    :type path: pathlib.Path
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(path, bbox_inches="tight", dpi=dpi)
    print(f"Figure saved to {path.resolve()}")


def graph_setup() -> None:
    sns.set_theme(
        context="paper",
        style="ticks",
        font="serif",
        rc={
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.grid": False,
        },
    )

    plt.rcParams.update(
        {
            "text.usetex": True,
            # Figure
            "figure.figsize": DEFAULT_FIGSIZE,
            "figure.dpi": 300,
            "savefig.dpi": 300,
            "savefig.bbox": "tight",
            "savefig.pad_inches": 0.02,
            # Fonts
            "font.family": "serif",
            "font.serif": ["Liberation Serif", "Nimbus Roman"],
            "font.size": 18,
            "axes.titlesize": 24,
            "axes.labelsize": 22,
            "xtick.labelsize": 14,
            "ytick.labelsize": 14,
            "legend.fontsize": 22,
            "legend.title_fontsize": 22,
            "figure.titlesize": 26,
            "figure.labelsize": 22,
            # Subplots
            "figure.subplot.wspace": 0.3,
            "figure.subplot.hspace": 0.7,
            "figure.subplot.bottom": 0.2,
            # Axes
            "axes.linewidth": 0.8,
            "axes.edgecolor": "black",
            "axes.grid": False,
            # Ticks
            "xtick.direction": "in",
            "ytick.direction": "in",
            "xtick.major.size": 4,
            "ytick.major.size": 4,
            "xtick.major.width": 0.8,
            "ytick.major.width": 0.8,
            "xtick.minor.visible": True,
            "ytick.minor.visible": True,
            # Lines
            "lines.linewidth": 1.5,
            "lines.markersize": 5,
            # Legend
            "legend.frameon": False,
            "legend.loc": "best",
            # Math text
            "mathtext.fontset": "cm",
            # PDF/PS output (important for LaTeX + journals)
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )
    sns.set_palette(COLORBLIND_PALETTE)
